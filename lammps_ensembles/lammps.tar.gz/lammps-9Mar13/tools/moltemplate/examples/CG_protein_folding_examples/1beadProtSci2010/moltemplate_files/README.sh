# run moltemplate this way

moltemplate.sh -overlay-dihdedrals system.lt

# This will generate various files with names ending in *.in* and *.data
# which are needed by LAMMPS.

