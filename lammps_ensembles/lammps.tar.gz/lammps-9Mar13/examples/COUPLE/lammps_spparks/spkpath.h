#define SPKPATH /home/sjplimp/spparks
